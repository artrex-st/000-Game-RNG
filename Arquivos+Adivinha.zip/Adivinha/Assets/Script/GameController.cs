﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    #region Variables
    [Header("Audios")]
    public AudioSource audioSource;
    public AudioClip clipAcerto, clipErro;

    [Space(10)]
    public Text txtAcerto;
    public Text txtErro;
    private int sortNumber, acertos = 0, erros = 0;
    #endregion

    //Start é chamado uma única vez, quando iniciado o script
    private void Start(){
        this.RandValue();
    }

    private void Update(){
        if(Input.GetKeyDown(KeyCode.Escape)){
            Application.Quit();
        }
    }
    private void PlayAcerto(){
        this.audioSource.clip = this.clipAcerto;
        this.audioSource.Play();
    }

    private void PlayErro(){
        this.audioSource.clip = this.clipErro;
        this.audioSource.Play();
    }

    private void RandValue(){
        this.sortNumber = UnityEngine.Random.Range(1, 3);
    }

    #region UI Elements
    public void Vote(int value){
        if(value == this.sortNumber){
            this.acertos++;
            this.PlayAcerto();
        }else{
            this.erros++;
            this.PlayErro();
        }

        this.RandValue();
        this.ChangeUI();
    }

    private void ChangeUI(){
        this.txtAcerto.text = string.Format("Acertos: {0}", this.acertos);
        this.txtErro.text = "Erros: " + this.erros;
    }
    #endregion
}
